class AWSConfig {
  static const String accessKeyId = 'YOUR_ACCESS_KEY_ID';
  static const String secretAccessKey = 'YOUR_SECRET_ACCESS_KEY';
  static const String region = 'YOUR_AWS_REGION';
  static const String platformEndpointArn = 'YOUR_PLATFORM_ENDPOINT_ARN';
  static const String snsTopicArn = 'YOUR_SNS_TOPIC_ARN';
}
