import 'package:flutter/material.dart';

class KpiPage extends StatelessWidget {
  const KpiPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('KPI'),
      ),
      body: const Center(
        child: Text('KPI Page'),
      ),
    );
  }
}
